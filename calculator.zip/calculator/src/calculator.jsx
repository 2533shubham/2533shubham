import "./calculator.css"

import { useState } from "react";



function Calculator(){
     //react js hooks
     let [result,Setresult]=useState("")
     let [history,Sethistory]=useState("")

     function display(e){  
         
         Sethistory(history.concat(e.target.name))
         Setresult(result.concat(e.target.name))
       
     }

    //  set result 

    function SetResult(){
        try{
            Setresult(eval(result))
        }
        catch(errr){
            Setresult("Error")
            
        }
        
    }

    //  clear input fields

    function clear(){
        Setresult(" ")
        Sethistory(" ")
    }
    // delete one character

    function delete_once(){
        
        Setresult(result.slice(0,result.length-1))
    }

    return <>

    <div className="calculator-box"> 

       <div className="result">
           <div className="history"><p>{history}</p></div>
           <div className="total-result"><h4>{result}</h4></div>
       </div>
       {/* end of resutl box */}

        <div className="button-box">
            <button name="AC" onClick={clear}>AC</button> 
            <button name="x" onClick={delete_once}>CE</button>
            <button name="%" onClick={display} >%</button>
            <button name="/" onClick={display} id="devide">/</button>
            <button name="7" onClick={display}>7</button>
            <button name="8" onClick={display}>8</button>
            <button name="9" onClick={display}>9</button>
            <button name="*" onClick={display} id="multi">X</button>
            <button name="4" onClick={display} >4</button>
            <button name="5" onClick={display}>5</button>
            <button name="6" onClick={display}>6</button>
            <button name="-" onClick={display} id="decrese">-</button>
            <button name="1" onClick={display}>1</button>
            <button name="2" onClick={display}>2</button>
            <button name="3" onClick={display}>3</button>
            <button name="+" onClick={display} id="add">+</button>
            <button name="0" onClick={display} id="empty"></button>
            <button name="." onClick={display}>0</button>
            <button name="." onClick={display} id="empty"></button>
            <button name="=" id="total" onClick={SetResult} >=</button>
        </div>


    </div>
    
    </>
}

export default Calculator ;
 