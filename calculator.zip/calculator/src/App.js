
import Calculator from './calculator';

function App(){
  return <>

  <Calculator/>
  
  </>
}
export default App;
