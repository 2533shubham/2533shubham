import React from "react"
import Weather from "./weather"
import "./weather.css";



const App=()=>{
  return <>
  
      <Weather/>
  </>
  
  
  
}

export default App;