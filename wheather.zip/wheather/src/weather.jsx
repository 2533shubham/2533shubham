import { useEffect, useState } from "react"

function Weather(){
    const [city, SetCity]=useState(null);
    const [search,Setsearch]=useState("mumbai");
    const [WIND,SetWind]=useState(null)

    

    useEffect(()=>{

    //    const  FetchApi=
    const FetchApi=async ()=>{

        const url="https://api.openweathermap.org/data/2.5/weather?q="+search+"&units=metric&appid=2c8843a655ca1d4fdbe9d730798c7fc1"
        const res=await fetch(url);
        const data=await res.json();
         SetCity(data.main);
        SetWind(data.wind.speed)
        // console.log(data.wind.speed)
        
        
        

    }


    FetchApi();
    },[search]);


    return <>

     
<header>Live Weather</header>
        <div className="weather-box">
            <div className="search"><input type="search" autoFocus onChange={(e)=>{Setsearch(e.target.value)}}/></div>
                {!city?<div id="error"><img src={process.env.PUBLIC_URL+"error.gif"}/><div className="message">city name is invalid</div></div>
                






                :
                 <div className="context">

                 <div className="logo-city"> <i class="fa fa-street-view"></i> <h1>{search}</h1>
                 </div>
                    
                <div className="cloud-img"><img src={ process.env.PUBLIC_URL+"weather.png" } /></div>
                 {/* <div className="cloud-img"><i class="fa fa-cloud"></i><i class="fa fa-sun-o"></i></div> */}
 
                 {/* end of cloudy image and search section */}
 
                 <div className="weather-temp">
                     <span id="temp">{city.temp}°</span> C
                 </div>

                 <div className="weather-info">
                     <div className="weathers">

                         <div className="info">
                             <i class='fas fa-temperature-high'></i>
                             <div className="info-value">
                                 <span>{city.temp_max}</span>
                                 <p>Maximum</p>
                             </div>
                         </div>

                         {/* end of info 1 */}

                         <div className="info" id="wind">
                             <i class='fas fa-wind'></i>
                             <div className="info-value">
                                  <span>{WIND}</span> 
                                 <p>wind</p>
                             </div>
                         </div>
                        





                     </div>
                 </div>
 
             </div>
             }
           
        </div>{/* end of weather box */}
        

    
    
    
    </>

}

export default Weather;